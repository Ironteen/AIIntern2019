# Introduction To RNNs in TensorFlow

Placeholder for future purposes
