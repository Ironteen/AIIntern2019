# Implementing NonLinear SVMs

Here we show how to use the prior Gaussian RBF kernel to predict I.setosa from the Iris dataset.

![Nonlinear SVM](../images/05_non_linear_svms.png "Nonlinear SVM")
