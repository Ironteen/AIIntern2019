# Implementing Multiclass SVMs

Here, we implement a 1-vs-all voting method for a multiclass SVM.  We attempt to separate the three Iris flower classes with TensorFlow.

![Multiclass SVM](../images/06_multiclass_svm.png "Multiclass SVM")
