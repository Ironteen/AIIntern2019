# Activation Functions

This script plots many various activation functions in TensorFlow.

![Activation Functions](../images/06_activation_funs1.png "Activation Functions")

![Activation Functions](../images/06_activation_funs2.png "Activation Functions")

### TO DO

 - Add more documentation, explanations, and resources.
