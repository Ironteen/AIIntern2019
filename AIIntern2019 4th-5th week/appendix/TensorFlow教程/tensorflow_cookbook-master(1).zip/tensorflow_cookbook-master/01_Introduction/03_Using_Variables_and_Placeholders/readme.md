# Variables and Placeholders

Here we initialize a simple placeholder for a piece of data.  We then feed a random number into an identity function.  If viewed in Tensorboard, the following graph will be created.

![Computational Graph](../images/03_placeholder.png "A Graph of a Variable and Placeholder")

### TO DO

 - Add more documentation, explanations, and resources.
