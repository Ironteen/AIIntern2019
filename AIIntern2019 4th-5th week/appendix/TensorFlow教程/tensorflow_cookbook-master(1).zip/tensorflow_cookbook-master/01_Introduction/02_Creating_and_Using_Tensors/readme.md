# Creating and Using Tensors

This script will produce a computational graph of initializing tensors.  Here is the output if viewed in Tensorboard:

![Computational Graph](../images/02_variable.png "Tensor Computational Graph")
