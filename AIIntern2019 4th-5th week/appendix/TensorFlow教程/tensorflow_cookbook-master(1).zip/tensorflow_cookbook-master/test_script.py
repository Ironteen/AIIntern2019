import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import sklearn
import requests
import jupyter
